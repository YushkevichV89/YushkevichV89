<?php
session_start();
require_once 'dbconnect.php';

if(isset($_POST['submit']))

{
    $login = $_POST['login'];
    $password = $_POST['password'];

    # Вытаскиваем из БД запись, у которой логин равняеться введенному

    $check_user = mysqli_query($connection, "SELECT * FROM `users` WHERE `login` = '$login' AND `password` = '$password'");
    if (mysqli_num_rows($check_user) > 0) {

        $user = mysqli_fetch_assoc($check_user);

        $_SESSION['message']="Вы авторизовались";
        $link="Перейти в личный кабинет";
        $_SESSION['user'] = [
            "id" => $user['id'],
            "full_name" => $user['full_name'],
            "avatar" => $user['avatar'],
            "email" => $user['email']
        ];
        header('Location: profile.php');
    }

    else

    {

        $fail="Вы ввели неправильный логин/пароль";

    }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        /* Remove the navbar's default margin-bottom and rounded borders */
        .navbar {
            margin-bottom: 0;
            border-radius: 0;
        }

        /* Add a gray background color and some padding to the footer */
        footer {
            background-color: #f2f2f2;
            padding: 25px;
        }

        .carousel-inner img {
            width: 100%; /* Set width to 100% */
            margin: auto;
            min-height:200px;
        }

        /* Hide the carousel text when the screen is less than 600 pixels wide */
        @media (max-width: 600px) {
            .carousel-caption {
                display: none;
            }
        }
        .form-signin{
            max-width: 400px;
            padding: 15px;
            margin: 0 auto;
        }
    </style>

</head>
<body>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div id="auth_block">
            <div id="link_auth">
                <div id="header">
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="form_auth.php"><span class="glyphicon glyphicon-log-in"></span> Войти</a></li>
                            <li><a href="index.php">Главная</a></li>
                            <li><a href="Res.php">Рестораны</a></li>
                            <li><a href="Blog.php">Отзывы</a></li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <li><a class="navbar-brand" href="#">Корзина</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
</nav>



</div>
<div class="container">
    <form method="post" class="form-signin">
        <h2 style="text-align: center">Авторизация</h2>
        <?php if($_SESSION['message']){
            ?><div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message'])?> </div> <?php } ?>
        <?php if(isset($fail)){?><div class="alert alert-danger role="alert"><?php echo $fail;?> </div><?php } ?>
        <input type="login" name="login" class="form-control" placeholder="login" required>
        <input type="password" name="password" class="form-control" placeholder="Пароль">
        <button class="btn btn-lg btn-primary btn-block"  name="submit" type="submit" style="max-width: 150px; display: inline-block">Войти</button>
        <a href="registration.php" class="btn btn-lg btn-primary btn-block" style="max-width: 150px;display: inline-block; float: right; margin: 0px">Регистрация</a>
        <br><?php if(isset($link)){?><a href="profile.php"><?php echo $link;?> </a><?php } ?>
    </form>
</div>



</body>