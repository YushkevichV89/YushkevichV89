<?php
session_start();
if (!$_SESSION['user']) {
    header('Location: form_auth.php');
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        /* Remove the navbar's default margin-bottom and rounded borders */
        .navbar {
            margin-bottom: 0;
            border-radius: 0;
        }

        /* Add a gray background color and some padding to the footer */
        footer {
            background-color: #f2f2f2;
            padding: 25px;
        }

        .carousel-inner img {
            width: 100%; /* Set width to 100% */
            margin: auto;
            min-height:200px;
        }

        /* Hide the carousel text when the screen is less than 600 pixels wide */
        @media (max-width: 600px) {
            .carousel-caption {
                display: none;
            }
        }
        .round {
            border-radius: 100px; /* Радиус скругления */
            border: 3px solid black; /* Параметры рамки */
            box-shadow: 0 0 7px #666; /* Параметры тени */
            width: 50px;
            height: 50px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div id="auth_block">
            <div id="link_auth">
                <div id="header">
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav">
                            <?php if(!$_SESSION){?><li class="active"><a href="form_auth.php"><span class="glyphicon glyphicon-log-in"></span> Войти</a></li><?php }
                            else ?><li><a href="profile.php" style="width: 10%;height: 10%; padding-bottom: 0; padding-top: 0">
                                    <img src="<?= $_SESSION['user']['avatar'] ?>" class="round"  alt=""></a></li>
                            <li><a href="index.php">Главная</a></li>
                            <li><a href="Res.php">Рестораны</a></li>
                            <li><a href="Blog.php">Отзывы</a></li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <li><a class="navbar-brand" href="#">Корзина</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
</nav>


<div class="col-sm-3">
    <div class="row">
        <div class="well">
    <form class="container-fluid bg-3 text-center">
        <img src="<?= $_SESSION['user']['avatar'] ?>" width="200" alt=""><br>
        <label>ФИО: <?php echo $_SESSION['user']['full_name'];?></label><br>
        <label>Email: <?php echo $_SESSION['user']['email'];?></label>
        <a href="logout.php" class="logout">Выход</a>

    </form>
        </div>
    </div>
</div>


</body>
</html>