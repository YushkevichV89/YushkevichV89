<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en" ng-app="restoranApp">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.7/angular.min.js"></script>
    <style>
        /* Remove the navbar's default margin-bottom and rounded borders */
        .navbar {
            margin-bottom: 0;
            border-radius: 0;
        }

        /* Add a gray background color and some padding to the footer */
        footer {
            background-color: #f2f2f2;
            padding: 25px;
        }

        .carousel-inner img {
            width: 100%; /* Set width to 100% */
            margin: auto;
            min-height:200px;
        }

        /* Hide the carousel text when the screen is less than 600 pixels wide */
        @media (max-width: 600px) {
            .carousel-caption {
                display: none;
            }
        }
        .round {
            border-radius: 100px; /* Радиус скругления */
            border: 3px solid black; /* Параметры рамки */
            box-shadow: 0 0 7px #666; /* Параметры тени */
            width: 50px;
            height: 50px;
        }
    </style>
    <script>
        var restoranApp = angular.module('restoranApp', []);
        restoranApp.controller('RestoranCtrl', function ($scope, $http){
            $http.get('restorans.json').success(function(data) {
                $scope.restorans = data;
            });
        });
    </script>
</head>
<body ng-controller="RestoranCtrl">
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div id="auth_block">
            <div id="link_auth">
                <div id="header">
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav">
                            <?php if(!$_SESSION){?><li><a href="form_auth.php"><span class="glyphicon glyphicon-log-in"></span> Войти</a></li><?php }
                            else {?><li><a href="profile.php" style="width: 10%;height: 10%; padding-bottom: 0; padding-top: 0">
                                    <img src="<?= $_SESSION['user']['avatar'] ?>" class="round"  alt=""></a></li> <?}?>
                            <li><a href="index.php">Главная</a></li>
                            <li class="active"><a href="Res.php">Рестораны</a></li>
                            <li><a href="Blog.php">Отзывы</a></li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <li><a class="navbar-brand" href="#">Корзина</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
</nav>


<div class="container-fluid bg-3 text-center">
    <div class="row">
        <div class="col-sm-3" ng-repeat="restoran in restorans">
            <div class="well">
                <p>{{restoran.text}}</p>
                <img src={{restoran.image}} class="img-responsive" style="width:100%" alt="Image">
            </div>
        </div>
    </div>
</div><br><br>
