<?php
session_start();


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        /* Remove the navbar's default margin-bottom and rounded borders */
        .navbar {
            margin-bottom: 0;
            border-radius: 0;
        }

        /* Add a gray background color and some padding to the footer */
        footer {
            background-color: #f2f2f2;
            padding: 25px;
        }

        .carousel-inner img {
            width: 100%; /* Set width to 100% */
            margin: auto;
            min-height:200px;
        }

        /* Hide the carousel text when the screen is less than 600 pixels wide */
        @media (max-width: 600px) {
            .carousel-caption {
                display: none;
            }
        }
        .round {
            border-radius: 100px; /* Радиус скругления */
            border: 3px solid black; /* Параметры рамки */
            box-shadow: 0 0 7px #666; /* Параметры тени */
            width: 50px;
            height: 50px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div id="auth_block">
            <div id="link_auth">
                <div id="header">
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
                <?php if(!$_SESSION){?><li><a href="form_auth.php"><span class="glyphicon glyphicon-log-in"></span> Войти</a></li><?php }
                else {?><li><a href="profile.php" style="width: 10%;height: 10%; padding-bottom: 0; padding-top: 0">
                        <img src="<?= $_SESSION['user']['avatar'] ?>" class="round"  alt=""></a></li> <?}?>
                <li class="active"><a href="#">Главная</a></li>
                <li><a href="Res.php">Рестораны</a></li>
                <li><a href="Blog.php">Отзывы</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a class="navbar-brand" href="#">Корзина</a></li>
            </ul>
        </div>
    </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
</nav>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img src="https://img03.rl0.ru/afisha/c1260x400i/s5.afisha.ru/mediastorage/97/6c/38a3efd4afad4156857b3d7e6c97.jpg" style="width: 100%;height: 500px" alt="Image">
            <div class="carousel-caption">
                <h3>DOCE UVAS</h3>
            </div>
        </div>

        <div class="item">
            <img src="https://1000svadeb.ru/files/cafe/464/59c2278d317ad.jpeg" style="width: 100%;height: 500px" alt="Image">
            <div class="carousel-caption">
                <h3>PARUS</h3>
            </div>
        </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<div class="container text-center">
    <h3>Блюдо дня</h3><br>
    <div class="row">
        <div class="col-sm-4">
            <img src="https://primpress.ru/img/cards/2018_01/9Sqnu0CKL6j82JGR_lg.jpg" class="img-responsive" style="width:100%; height: 250px"  alt="Image">
            <p>Паста по-итальянски</p>
        </div>
        <div class="col-sm-4">
            <img src="https://www.koolinar.ru/all_image/recipes/141/141805/recipe_9e65118d-b6e0-445f-b302-b19ab7ee82d8.jpg" class="img-responsive" style="width:100%; height: 250px" alt="Image">
            <p>Пицца пепперони</p>
        </div>
        <div class="col-sm-4">
            <img src="https://avatars.mds.yandex.net/get-pdb/1605413/057e4167-a52f-4043-bc83-10fd0aad02db/s1200?webp=false" style="width:100%; height: 250px" alt="Image">
            <p>Салат цезарь</p>
        </div>
        <div class="col-sm-4">
            <img src="https://cs8.pikabu.ru/post_img/2017/02/16/6/og_og_148723805022381318.jpg" style="width:100%; height: 250px" alt="Image">
            <p>Бефстроганов</p>
        </div>
        <div class="col-sm-4">
            <img src="https://img09.rl0.ru/eda/c620x415i/s1.eda.ru/StaticContent/Photos/120131083953/170906184644/p_O.jpg" style="width:100%; height: 250px" alt="Image">
            <p>Булочка с корицей</p>
        </div>
        <div class="col-sm-4">
            <img src="https://otvet.imgsmail.ru/download/a1bc5b0b0f81adacc489351fccc7aa0e_i-108.jpg" style="width:100%; height: 250px" alt="Image">
            <p>Рожки с голландским сыром</p>
        </div>
    </div>
</div><br>


</body>
</html>
