<?php
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        /* Remove the navbar's default margin-bottom and rounded borders */
        .navbar {
            margin-bottom: 0;
            border-radius: 0;
        }

        /* Add a gray background color and some padding to the footer */
        footer {
            background-color: #f2f2f2;
            padding: 25px;
        }

        .carousel-inner img {
            width: 100%; /* Set width to 100% */
            margin: auto;
            min-height:200px;
        }

        /* Hide the carousel text when the screen is less than 600 pixels wide */
        @media (max-width: 600px) {
            .carousel-caption {
                display: none;
            }
        }
        .form-signin{
            max-width: 400px;
            padding: 15px;
            margin: 0 auto;
        }
    </style>

</head>
<body>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div id="auth_block">
            <div id="link_auth">
                <div id="header">
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav">
                            <li class="active"><a href="form_auth.php"><span class="glyphicon glyphicon-log-in"></span> Войти</a></li>
                            <li><a href="index.php">Главная</a></li>
                            <li><a href="Res.php">Рестораны</a></li>
                            <li><a href="Blog.php">Отзывы</a></li>
                        </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <li><a class="navbar-brand" href="#">Корзина</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
</nav>

<?php
require('dbconnect.php');
if (filter_var($_POST['email'],FILTER_VALIDATE_EMAIL) && strlen($_POST['password'])>=8){
    if (isset($_POST['fullname']) && isset($_POST['login']) && isset($_POST['password'])) {
        $fullname = $_POST['fullname'];
        $login = $_POST['login'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $query = "INSERT INTO users(full_name, login ,email, password) VALUES ('$fullname','$login','$email', '$password')";
        $result = mysqli_query($connection, $query);


    }
    if ($result) {
        $smsg = "Регистрация успешна";
    } else {
        $fsmsg = "Ошибка";
    }
}
?>

<div class="container">
    <form method="post" class="form-signin">
        <h2>Регистрация</h2>
        <?php if(isset($smsg)){?><div class="alert alert-success role="alert"><?php echo $smsg; $connection->close();?> </div><?php } ?>
        <?php if(isset($fsmsg)){?><div class="alert alert-danger role="alert"><?php echo $fsmsg;?> </div><?php } ?>
<input type="text" name="fullname" class="form-control" placeholder="ФИО" required>
<input type="text" name="login" class="form-control" placeholder="login" required>
<input type="email" name="email" class="form-control" placeholder="email" required>
<span id="valid_email_message" class="message_error"></span>
<input type="password" name="password" class="form-control" placeholder="Пароль" required>
<span id="valid_password_message" class="message_error"></span>
<button class="btn btn-lg btn-primary btn-block"  name="btn_submit_register" type="submit">Зарегистрироваться</button>
</form>
</div>
</body>

